class Hitung():
    def jumlah(self, x, y):
        jumlah = x + y
        return jumlah

    def kurang(self, x, y):
        kurang = x - y
        return kurang

    def kali(self, x, y):
        kali = x * y
        return kali

    def bagi(self, x, y):
        bagi = x / y
        return bagi

def hitung_luas_lingkaran(r):
    luas = 3.14 * r * r
    return luas
